package com.aething.aistore;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
