import { 
  users, type User, type InsertUser, type UpdateUser, 
  products, type Product, type InsertProduct,
  orders, type Order, type InsertOrder
} from "@shared/schema";
import crypto from "crypto";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: UpdateUser): Promise<User | undefined>;
  updateUserVerification(id: number, isVerified: boolean): Promise<User | undefined>;
  generateVerificationToken(userId: number): Promise<string>;
  verifyUserByToken(token: string): Promise<User | undefined>;
  updateUserStripeCustomerId(userId: number, customerId: string): Promise<User | undefined>;
  updateUserStripeSubscriptionId(userId: number, subscriptionId: string): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Product methods
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  syncStripeProducts(): Promise<Product[]>;
  getProductByStripeId(stripeId: string): Promise<Product | undefined>;
  getProductsByCountry(country: string | null | undefined): Promise<Product[]>;

  // Order methods
  createOrder(order: InsertOrder): Promise<Order>;
  getOrdersByUserId(userId: number): Promise<Order[]>;
  getOrderByStripePaymentId(stripePaymentId: string): Promise<Order | undefined>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  updateOrderStripePaymentId(id: number, paymentId: string): Promise<Order | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private userIdCounter: number;
  private productIdCounter: number;
  private orderIdCounter: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.userIdCounter = 1;
    this.productIdCounter = 1;
    this.orderIdCounter = 1;

    // Initialize with some products
    const productsList: InsertProduct[] = [
      {
        title: "AI Personal Assistant",
        description: "Your intelligent companion for everyday tasks and reminders. This advanced AI assistant learns your preferences and adapts to your lifestyle, helping you stay organized and efficient.",
        price: 14999, // $149.99
        priceEUR: 13999, // €139.99
        imageUrl: "https://images.unsplash.com/photo-1673203834806-c320f851c9f9?auto=format&fit=crop&w=400&h=300",
        category: "Productivity",
        features: [
          "Advanced voice recognition",
          "Smart home integration",
          "Personalized recommendations",
          "Cloud-based processing",
          "Regular updates and improvements"
        ],
        specifications: [
          "Dimensions: 4.5\" x 4.5\" x 6.3\"",
          "Weight: 420g",
          "Connectivity: Wi-Fi, Bluetooth 5.0",
          "Power: AC Adapter (included)",
          "Warranty: 1 year limited"
        ]
      },
      {
        title: "AI Home Hub",
        description: "Control your smart home with advanced voice recognition technology. Connect all your smart devices and manage them from a central hub with intuitive voice commands or the companion app.",
        price: 29999, // $299.99
        priceEUR: 27999, // €279.99
        imageUrl: "https://images.unsplash.com/photo-1677442135146-1d91a759eee8?auto=format&fit=crop&w=400&h=300",
        category: "Smart Home",
        features: [
          "Multi-room audio",
          "Compatible with major smart home ecosystems",
          "Energy usage monitoring",
          "Voice-controlled shopping",
          "Multi-user recognition"
        ],
        specifications: [
          "Dimensions: 5.7\" x 5.7\" x 4.2\"",
          "Weight: 580g",
          "Connectivity: Wi-Fi, Bluetooth 5.0, Zigbee",
          "Power: AC Adapter (included)",
          "Warranty: 2 years limited"
        ]
      },
      {
        title: "AI Learning Device",
        description: "Personalized education system with adaptive learning algorithms. This device tailors educational content to individual learning styles and progress, making learning more engaging and effective.",
        price: 19999, // $199.99
        priceEUR: 18999, // €189.99
        imageUrl: "https://images.unsplash.com/photo-1655720031554-a929595d5fb0?auto=format&fit=crop&w=400&h=300",
        category: "Education",
        features: [
          "Personalized learning paths",
          "Progress tracking",
          "Interactive lessons",
          "Parent/teacher dashboard",
          "Offline content access"
        ],
        specifications: [
          "Dimensions: 9.5\" x 6.3\" x 0.4\"",
          "Weight: 350g",
          "Connectivity: Wi-Fi, Bluetooth 4.2",
          "Battery: Up to 12 hours",
          "Warranty: 1 year limited"
        ]
      },
      {
        title: "AI Health Monitor",
        description: "Track your health metrics with precision and get AI-powered insights for better wellbeing. Monitor vital signs, activity levels, sleep patterns, and receive personalized recommendations.",
        price: 24999, // $249.99
        priceEUR: 22999, // €229.99
        imageUrl: "https://images.unsplash.com/photo-1686191669169-b42fcd632af0?auto=format&fit=crop&w=600&h=400",
        category: "Health & Fitness",
        features: [
          "24/7 heart rate monitoring",
          "Sleep quality analysis",
          "Stress level tracking",
          "Exercise recognition",
          "Personalized health insights"
        ],
        specifications: [
          "Dimensions: 44mm x 38mm x 10.7mm",
          "Weight: 48g",
          "Connectivity: Bluetooth 5.1, NFC",
          "Battery: Up to 7 days",
          "Water resistance: 5 ATM"
        ]
      }
    ];

    productsList.forEach(product => this.createProduct(product));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id, 
      isVerified: false,
      verificationToken: this.generateRandomToken(),
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      name: null,
      phone: null,
      country: null,
      street: null,
      house: null,
      apartment: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: UpdateUser): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserVerification(id: number, isVerified: boolean): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, isVerified };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async generateVerificationToken(userId: number): Promise<string> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const token = this.generateRandomToken();
    const updatedUser = { ...user, verificationToken: token };
    this.users.set(userId, updatedUser);
    
    return token;
  }

  private generateRandomToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  async verifyUserByToken(token: string): Promise<User | undefined> {
    const user = Array.from(this.users.values()).find(
      (user) => user.verificationToken === token
    );
    
    if (!user) return undefined;
    
    const updatedUser = { ...user, isVerified: true, verificationToken: null };
    this.users.set(user.id, updatedUser);
    return updatedUser;
  }

  async updateUserStripeCustomerId(userId: number, customerId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, stripeCustomerId: customerId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserStripeSubscriptionId(userId: number, subscriptionId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, stripeSubscriptionId: subscriptionId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // Проверяем существование пользователя
    if (!this.users.has(id)) {
      return false;
    }
    
    // Удаляем пользователя
    const deleted = this.users.delete(id);
    
    // Также удаляем все связанные заказы (необязательно, но для чистоты данных)
    const userOrders = Array.from(this.orders.values())
      .filter(order => order.userId === id)
      .map(order => order.id);
    
    userOrders.forEach(orderId => this.orders.delete(orderId));
    
    // Если бы здесь была интеграция с Google Sheets, мы бы отправили уведомление
    // об удалении пользователя в Google Sheets
    
    return deleted;
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const product: Product = { 
      ...insertProduct, 
      id,
      features: insertProduct.features || [],
      specifications: insertProduct.specifications || [],
      stripeProductId: insertProduct.stripeProductId || null
    };
    this.products.set(id, product);
    return product;
  }
  
  async syncStripeProducts(): Promise<Product[]> {
    // This would call the Stripe API in a real implementation
    // For our prototype, we'll simulate this by adding stripeProductIds to existing products
    const products = Array.from(this.products.values());
    const updatedProducts: Product[] = [];
    
    for (const product of products) {
      // Only update products that don't have a stripeProductId
      if (!product.stripeProductId) {
        const updatedProduct = {
          ...product,
          stripeProductId: `prod_${Math.random().toString(36).substring(2, 10)}`
        };
        this.products.set(product.id, updatedProduct);
        updatedProducts.push(updatedProduct);
      } else {
        updatedProducts.push(product);
      }
    }
    
    return updatedProducts;
  }
  
  async getProductByStripeId(stripeId: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.stripeProductId === stripeId
    );
  }
  
  async getProductsByCountry(country: string | null | undefined): Promise<Product[]> {
    // All products are available in all countries in our prototype
    // But in a real implementation, you might filter products based on availability
    return this.getProducts();
  }

  // Order methods
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const now = new Date();
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt: now,
      userId: insertOrder.userId || null,
      productId: insertOrder.productId || null,
      currency: insertOrder.currency || 'usd',
      stripePaymentId: insertOrder.stripePaymentId || null
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrdersByUserId(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }
  
  async getOrderByStripePaymentId(stripePaymentId: string): Promise<Order | undefined> {
    return Array.from(this.orders.values()).find(
      (order) => order.stripePaymentId === stripePaymentId
    );
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async updateOrderStripePaymentId(id: number, paymentId: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, stripePaymentId: paymentId };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

export const storage = new MemStorage();
