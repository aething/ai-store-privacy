import { useState, useEffect } from 'react';
import { useAppContext } from '@/context/AppContext';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export interface Order {
  id: number;
  userId: number;
  productId: number;
  status: string;
  amount: number;
  currency: string;
  stripePaymentId: string | null;
  trackingNumber: string | null;
  couponCode: string | null;
  createdAt: string;
  product?: {
    title: string;
    imageUrl: string;
    price: number;
  };
}

// Демо-данные для неавторизованных пользователей
const DEMO_ORDERS: Order[] = [
  {
    id: 1001,
    userId: 999,
    productId: 1,
    status: 'ordered',
    amount: 299.99,
    currency: 'USD',
    stripePaymentId: 'demo_payment_id_1',
    trackingNumber: null,
    couponCode: 'WELCOME20',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    product: {
      title: 'AI Personal Assistant',
      imageUrl: '/assets/products/assistant.jpg',
      price: 299.99
    }
  } as Order,
  {
    id: 1002,
    userId: 999,
    productId: 2,
    status: 'shipped',
    amount: 149.99,
    currency: 'USD',
    stripePaymentId: 'demo_payment_id_2',
    trackingNumber: 'DEMO123456789',
    couponCode: null,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    product: {
      title: 'Smart Home Hub',
      imageUrl: '/assets/products/smart-home.jpg',
      price: 149.99
    }
  } as Order,
  {
    id: 1003,
    userId: 999,
    productId: 3,
    status: 'complete',
    amount: 199.99,
    currency: 'USD',
    stripePaymentId: 'demo_payment_id_3',
    trackingNumber: 'DEMO987654321',
    couponCode: 'SUMMER15',
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    product: {
      title: 'Wireless Earbuds',
      imageUrl: '/assets/products/earbuds.jpg',
      price: 199.99
    }
  } as Order
];

// Хранение демо-данных между рендерами
let demoOrdersState = [...DEMO_ORDERS];

export function useOrders(isDemoMode = false) {
  const { user } = useAppContext();
  const [demoOrders, setDemoOrders] = useState<Order[]>(demoOrdersState);
  
  // Определяем, используем ли демо-режим
  // - В демо-режиме или во время разработки показываем демо заказы
  // - В продакшене показываем демо только если явно запрошено isDemoMode=true
  const shouldUseDemoOrders = () => {
    // Если пользователь авторизован, всегда используем настоящие данные
    if (user?.id) return false;
    
    // В противном случае решаем на основе окружения и флага isDemoMode
    return process.env.NODE_ENV !== 'production' || isDemoMode;
  };
  
  // Определяем, нужно ли выполнять запрос
  const shouldFetchData = Boolean(user?.id || shouldUseDemoOrders());
  
  const {
    data: orders,
    isLoading,
    isError,
    refetch
  } = useQuery({
    queryKey: ['/api/users/orders', user?.id],
    queryFn: async () => {
      // Если пользователь не авторизован и демо включено - возвращаем демо заказы
      if (!user?.id && shouldUseDemoOrders()) return demoOrders;
      
      // Если пользователь не авторизован и демо выключено - возвращаем пустой массив
      if (!user?.id) return [];
      
      // Иначе делаем запрос к API для получения настоящих заказов
      const response = await apiRequest('GET', `/api/users/${user.id}/orders`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch orders');
      }
      
      const orderData = await response.json();
      return orderData as Order[];
    },
    enabled: shouldFetchData // Используем заранее вычисленное boolean значение
  });
  
  const updateOrderTrackingNumber = async (orderId: number, trackingNumber: string) => {
    // Для демо-режима - обновляем локальное состояние
    if (!user?.id && shouldUseDemoOrders()) {
      const updatedDemoOrders = demoOrders.map(order => 
        order.id === orderId ? { ...order, trackingNumber } : order
      );
      setDemoOrders(updatedDemoOrders);
      demoOrdersState = updatedDemoOrders; // Обновляем глобальное состояние
      return { ...demoOrders.find(o => o.id === orderId), trackingNumber };
    }
    
    // Для авторизованных пользователей - отправляем на сервер
    const response = await apiRequest('POST', `/api/orders/${orderId}/update-tracking`, { trackingNumber });
    
    if (!response.ok) {
      throw new Error('Failed to update tracking number');
    }
    
    const updatedOrder = await response.json();
    await refetch(); // Reload the orders after updating
    
    return updatedOrder;
  };
  
  return {
    orders: user?.id ? (orders || []) : (shouldUseDemoOrders() ? demoOrders : []),
    isLoading: user?.id ? isLoading : false,
    isError: user?.id ? isError : false,
    updateOrderTrackingNumber,
    refetch
  };
}